
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import apiServerClient from '@/lib/apiServerClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';

const BlogPage = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const { authToken } = useAuth();

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await apiServerClient.fetch('/content/private-room?type=blog', {
          headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!response.ok) throw new Error('Failed to fetch content');

        const data = await response.json();
        setContent(data);
      } catch (error) {
        console.error('Content fetch error:', error);
      } finally {
        setLoading(false);
      }
    };

    if (authToken) {
      fetchContent();
    }
  }, [authToken]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-gold-500 text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Blog - Private Room - Apple Juicy Entertainment</title>
        <meta name="description" content="Exclusive blog posts and stories for VIP members." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <div className="inline-block bg-gold-500/10 border border-gold-500/20 rounded-full px-6 py-2 mb-6">
                <span className="text-gold-500 font-semibold text-sm tracking-wider uppercase">
                  Members Only
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Exclusive Blog
              </h1>
            </motion.div>

            {content.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-white/60">No blog posts available yet. Check back soon.</p>
              </div>
            ) : (
              <div className="space-y-8">
                {content.map((item, index) => (
                  <motion.article
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="bg-neutral-900 border border-gold-500/20 rounded-2xl overflow-hidden"
                  >
                    {item.image && (
                      <img
                        src={pb.files.getUrl(item, item.image)}
                        alt={item.title}
                        className="w-full h-80 object-cover"
                      />
                    )}
                    <div className="p-8">
                      <h2 className="text-2xl font-bold mb-4">{item.title}</h2>
                      {item.content && (
                        <p className="text-white/70 leading-relaxed">{item.content}</p>
                      )}
                    </div>
                  </motion.article>
                ))}
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default BlogPage;
