import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const SuccessPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/private-room');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <>
      <Helmet>
        <title>Payment Successful - Apple Juicy Entertainment</title>
        <meta name="description" content="Your payment was successful. Welcome to the exclusive members area." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24 min-h-screen flex items-center justify-center">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
            >
              <div className="bg-neutral-900 border border-gold-500/20 rounded-2xl p-12">
                <div className="flex justify-center mb-6">
                  <CheckCircle className="w-20 h-20 text-green-500" />
                </div>

                <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gold-500">
                  Payment Successful
                </h1>

                <p className="text-lg text-white/70 mb-8">
                  Welcome to the exclusive members area. Your subscription is now active.
                </p>

                <p className="text-white/60 mb-8">
                  Redirecting to Private Room in {countdown} seconds...
                </p>

                <Button
                  onClick={() => navigate('/private-room')}
                  className="bg-gold-500 text-black hover:bg-gold-400 font-semibold px-8 py-6 text-lg"
                >
                  Go to Private Room Now
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default SuccessPage;