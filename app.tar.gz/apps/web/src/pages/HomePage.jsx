import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
const HomePage = () => {
  return <>
      <Helmet>
        <title>Apple Jucy Exotic Adult Entertainment - Enter the Experience</title>
        <meta name="description" content="Exclusive premium entertainment and content for discerning members. Enter a world of erotica and sensuality." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
          <div className="absolute inset-0">
            <img src="https://horizons-cdn.hostinger.com/6d4295e9-9132-4679-9000-f39427a4b140/youtube-banner-AppleJucy-Exotic-Adult-Entertainment.png" alt="Apple Jucy Entertainment erotic experience" className="w-full h-full object-cover opacity-40" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black"></div>
          </div>

          <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8
          }} className="text-5xl md:text-7xl font-bold mb-6" style={{
            letterSpacing: '-0.02em'
          }}>
              <span className="text-gold-500">Enter the</span>
              <br />
              <span className="text-white">Experience</span>
            </motion.h1>

            <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8,
            delay: 0.2
          }} className="text-xl md:text-2xl text-white/80 mb-12 leading-relaxed max-w-2xl mx-auto">
              Join me every night for live, interactive shows where you control the fun. Real energy. Real connection. Zero boring.
            </motion.p>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8,
            delay: 0.4
          }}>
              <Button asChild className="bg-gold-500 text-black hover:bg-gold-400 font-semibold px-12 py-6 text-lg">
                <Link to="/contact">Call Me</Link>
              </Button>
            </motion.div>
          </div>
        </section>

        <section className="py-24 bg-gradient-to-b from-black to-neutral-950">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} viewport={{
            once: true
          }} className="text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gold-500">
                The Party's Live. Are You In?
              </h2>
              <p className="text-lg text-white/70 leading-relaxed mb-8">
                Join me every night for live, interactive shows where you control the fun. Real energy. Real connection. Zero boring.
              </p>
              <p className="text-lg text-white/70 leading-relaxed">
                What's Happening Inside
More Than a Stream. It's an Experience.
              </p>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>;
};
export default HomePage;