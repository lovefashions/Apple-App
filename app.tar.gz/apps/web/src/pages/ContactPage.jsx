
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import apiServerClient from '@/lib/apiServerClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await apiServerClient.fetch('/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (!response.ok) throw new Error('Failed to send message');

      toast('Message sent successfully');
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      toast('Failed to send message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/1234567890', '_blank');
  };

  return (
    <>
      <Helmet>
        <title>Contact - Apple Juicy Entertainment</title>
        <meta name="description" content="Get in touch with Apple Juicy Entertainment. Send us a message or connect via WhatsApp." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Get in Touch
              </h1>
              <p className="text-lg text-white/70">
                Have questions? Want to learn more? Reach out to us.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Input
                      type="text"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      className="bg-neutral-900 border-gold-500/20 text-white placeholder:text-white/40"
                    />
                  </div>
                  <div>
                    <Input
                      type="email"
                      placeholder="Your Email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="bg-neutral-900 border-gold-500/20 text-white placeholder:text-white/40"
                    />
                  </div>
                  <div>
                    <Textarea
                      placeholder="Your Message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                      rows={6}
                      className="bg-neutral-900 border-gold-500/20 text-white placeholder:text-white/40"
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gold-500 text-black hover:bg-gold-400 font-semibold"
                  >
                    {loading ? 'Sending...' : 'Send Message'}
                  </Button>
                </form>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex flex-col justify-center"
              >
                <img
                  src="https://horizons-cdn.hostinger.com/6d4295e9-9132-4679-9000-f39427a4b140/e4246bb57679f4d4d792a7f236917c2d.png"
                  alt="Contact Apple Juicy Entertainment"
                  className="w-full rounded-2xl mb-8"
                />
                <Button
                  onClick={handleWhatsApp}
                  className="bg-green-600 hover:bg-green-500 text-white font-semibold"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Connect on WhatsApp
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default ContactPage;
