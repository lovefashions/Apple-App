import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const CancelPage = () => {
  return (
    <>
      <Helmet>
        <title>Payment Cancelled - Apple Juicy Entertainment</title>
        <meta name="description" content="Your payment was cancelled. You can try again anytime." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24 min-h-screen flex items-center justify-center">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
            >
              <div className="bg-neutral-900 border border-gold-500/20 rounded-2xl p-12">
                <div className="flex justify-center mb-6">
                  <XCircle className="w-20 h-20 text-red-500" />
                </div>

                <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gold-500">
                  Payment Cancelled
                </h1>

                <p className="text-lg text-white/70 mb-8">
                  Your payment was not completed. No charges were made.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    asChild
                    className="bg-gold-500 text-black hover:bg-gold-400 font-semibold"
                  >
                    <Link to="/private-room">Try Again</Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-gold-500/20 text-white hover:bg-white/5"
                  >
                    <Link to="/">Back to Home</Link>
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default CancelPage;