
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { User, Mail, ShoppingBag, Home, Lock } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const MorePage = () => {
  const links = [
    { name: 'Home', path: '/', icon: Home, description: 'Return to homepage' },
    { name: 'Bio', path: '/bio', icon: User, description: 'Meet the creator' },
    { name: 'Contact', path: '/contact', icon: Mail, description: 'Get in touch' },
    { name: 'Store', path: '/store', icon: ShoppingBag, description: 'Exclusive content' },
    { name: 'Private Room', path: '/private-room', icon: Lock, description: 'Members only area' },
  ];

  return (
    <>
      <Helmet>
        <title>More - Apple Juicy Entertainment</title>
        <meta name="description" content="Explore all sections of Apple Juicy Entertainment. Navigate to exclusive content and experiences." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Explore More
              </h1>
              <p className="text-lg text-white/70">
                Navigate to all sections of Apple Juicy Entertainment
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {links.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Link
                    to={link.path}
                    className="block bg-neutral-900 border border-gold-500/20 rounded-2xl p-6 hover:border-gold-500/40 hover:shadow-lg hover:shadow-gold-500/10 transition-all duration-200"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="bg-gold-500/10 p-3 rounded-xl">
                        <link.icon className="w-6 h-6 text-gold-500" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{link.name}</h3>
                        <p className="text-white/60 text-sm">{link.description}</p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default MorePage;
