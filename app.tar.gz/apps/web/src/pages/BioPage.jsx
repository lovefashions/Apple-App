
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const BioPage = () => {
  return (
    <>
      <Helmet>
        <title>Bio - Apple Juicy Entertainment</title>
        <meta name="description" content="Meet the creator behind Apple Juicy Entertainment. Discover the vision and passion that drives our exclusive content." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <img
                  src="https://horizons-cdn.hostinger.com/6d4295e9-9132-4679-9000-f39427a4b140/fcd4984134579a280c482f861c57a860.png"
                  alt="Creator of Apple Juicy Entertainment"
                  className="w-full rounded-2xl shadow-2xl"
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                  The Creator
                </h1>
                <p className="text-lg text-white/80 leading-relaxed mb-6">
                  Behind Apple Juicy Entertainment is a visionary dedicated to crafting unforgettable experiences. With a passion for artistry and an eye for luxury, every piece of content is meticulously curated.
                </p>
                <p className="text-lg text-white/80 leading-relaxed mb-6">
                  From exclusive photography to intimate storytelling, the mission is simple: create a space where beauty, sensuality, and sophistication converge.
                </p>
                <p className="text-lg text-white/80 leading-relaxed">
                  Join the private community and discover content that transcends the ordinary.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default BioPage;
