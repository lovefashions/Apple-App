
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import apiServerClient from '@/lib/apiServerClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';

const GalleryPage = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const { authToken } = useAuth();

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await apiServerClient.fetch('/content/private-room?type=gallery', {
          headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!response.ok) throw new Error('Failed to fetch content');

        const data = await response.json();
        setContent(data);
      } catch (error) {
        console.error('Content fetch error:', error);
      } finally {
        setLoading(false);
      }
    };

    if (authToken) {
      fetchContent();
    }
  }, [authToken]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-gold-500 text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Gallery - Private Room - Apple Juicy Entertainment</title>
        <meta name="description" content="Exclusive photo gallery for VIP members only." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <div className="inline-block bg-gold-500/10 border border-gold-500/20 rounded-full px-6 py-2 mb-6">
                <span className="text-gold-500 font-semibold text-sm tracking-wider uppercase">
                  Members Only
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Exclusive Gallery
              </h1>
            </motion.div>

            {content.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-white/60">No gallery items available yet. Check back soon.</p>
              </div>
            ) : (
              <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
                {content.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="break-inside-avoid bg-neutral-900 border border-gold-500/20 rounded-2xl overflow-hidden"
                  >
                    {item.image && (
                      <img
                        src={pb.files.getUrl(item, item.image)}
                        alt={item.title}
                        className="w-full object-cover"
                      />
                    )}
                    <div className="p-4">
                      <h3 className="font-semibold">{item.title}</h3>
                      {item.content && (
                        <p className="text-sm text-white/70 mt-2">{item.content}</p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default GalleryPage;
