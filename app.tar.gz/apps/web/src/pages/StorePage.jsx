import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const StorePage = () => {
  return (
    <>
      <Helmet>
        <title>Store - Apple Juicy Entertainment</title>
        <meta name="description" content="Unlock exclusive premium content and merchandise from Apple Juicy Entertainment." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Exclusive Store
              </h1>
              <p className="text-lg text-white/70">
                Premium content and experiences for members only
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <img
                  src="https://horizons-cdn.hostinger.com/6d4295e9-9132-4679-9000-f39427a4b140/07c58cec859afe82654af01fbc6eb8d6.png"
                  alt="Exclusive Apple Juicy Entertainment store"
                  className="w-full rounded-2xl shadow-2xl"
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="space-y-6"
              >
                <div className="flex items-center space-x-3 text-gold-500">
                  <Lock className="w-6 h-6" />
                  <span className="text-sm font-semibold tracking-wider uppercase">Members Only</span>
                </div>

                <h2 className="text-3xl md:text-4xl font-bold">
                  Unlock Premium Access
                </h2>

                <p className="text-lg text-white/70 leading-relaxed">
                  Gain exclusive access to premium photo galleries, behind-the-scenes content, intimate stories, and limited edition merchandise.
                </p>

                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start">
                    <span className="text-gold-500 mr-2">•</span>
                    <span>Exclusive photo galleries and videos</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-gold-500 mr-2">•</span>
                    <span>Behind-the-scenes content</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-gold-500 mr-2">•</span>
                    <span>Limited edition merchandise</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-gold-500 mr-2">•</span>
                    <span>Direct access to exclusive updates</span>
                  </li>
                </ul>

                <Button
                  asChild
                  className="bg-gold-500 text-black hover:bg-gold-400 font-semibold px-8 py-6 text-lg"
                >
                  <Link to="/login">Unlock Access</Link>
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default StorePage;