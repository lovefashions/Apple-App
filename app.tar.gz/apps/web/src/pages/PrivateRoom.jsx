
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Newspaper, Briefcase, Image, Sparkles, BookOpen, ShoppingBag, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import apiServerClient from '@/lib/apiServerClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import CheckoutButton from '@/components/CheckoutButton.jsx';

const PrivateRoom = () => {
  const { subscription, authToken, refreshSubscription } = useAuth();
  const [accessData, setAccessData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      try {
        const response = await apiServerClient.fetch('/access/check', {
          headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!response.ok) throw new Error('Failed to check access');

        const data = await response.json();
        setAccessData(data);
      } catch (error) {
        console.error('Access check error:', error);
      } finally {
        setLoading(false);
      }
    };

    if (authToken) {
      checkAccess();
      refreshSubscription();
    }
  }, [authToken, refreshSubscription]);

  const sections = [
    { name: 'News', path: '/private-room/news', icon: Newspaper, color: 'text-blue-400' },
    { name: 'Portfolio', path: '/private-room/portfolio', icon: Briefcase, color: 'text-purple-400' },
    { name: 'Gallery', path: '/private-room/gallery', icon: Image, color: 'text-pink-400' },
    { name: 'Extras', path: '/private-room/extras', icon: Sparkles, color: 'text-yellow-400' },
    { name: 'Blog', path: '/private-room/blog', icon: BookOpen, color: 'text-green-400' },
    { name: 'Store', path: '/private-room/store', icon: ShoppingBag, color: 'text-red-400' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-gold-500 text-xl">Loading...</div>
      </div>
    );
  }

  const hasAccess = accessData?.hasAccess;

  return (
    <>
      <Helmet>
        <title>Private Room - Apple Juicy Entertainment</title>
        <meta name="description" content="Exclusive members-only content and experiences." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Header />

        <section className="pt-32 pb-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <div className="inline-block bg-gold-500/10 border border-gold-500/20 rounded-full px-6 py-2 mb-6">
                <span className="text-gold-500 font-semibold text-sm tracking-wider uppercase">
                  VIP Members Only
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gold-500" style={{ letterSpacing: '-0.02em' }}>
                Private Room
              </h1>
              <p className="text-lg text-white/70">
                Your exclusive gateway to premium content
              </p>
            </motion.div>

            {hasAccess && subscription && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-neutral-900 border border-gold-500/20 rounded-2xl p-6 mb-12 flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-gold-500" />
                  <div>
                    <p className="text-sm text-white/60">Membership Status</p>
                    <p className="font-semibold text-gold-500">
                      {accessData.daysRemaining} days remaining
                    </p>
                  </div>
                </div>
                <p className="text-sm text-white/60">
                  Expires: {new Date(subscription.expires_at).toLocaleDateString()}
                </p>
              </motion.div>
            )}

            {!hasAccess && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-neutral-900 border border-gold-500/20 rounded-2xl p-8 mb-12 text-center"
              >
                <h2 className="text-2xl font-bold mb-4 text-gold-500">
                  Unlock Premium Access
                </h2>
                <p className="text-white/70 mb-6">
                  Subscribe now to access exclusive content, galleries, and experiences
                </p>
                <CheckoutButton amount={30} productName="Apple Juicy Entertainment Membership" />
              </motion.div>
            )}

            {hasAccess && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sections.map((section, index) => (
                  <motion.div
                    key={section.path}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  >
                    <Link
                      to={section.path}
                      className="block bg-neutral-900 border border-gold-500/20 rounded-2xl p-6 hover:border-gold-500/40 hover:shadow-lg hover:shadow-gold-500/10 transition-all duration-200 h-full"
                    >
                      <div className="flex flex-col items-center text-center space-y-4">
                        <div className="bg-gold-500/10 p-4 rounded-xl">
                          <section.icon className={`w-8 h-8 ${section.color}`} />
                        </div>
                        <h3 className="text-xl font-semibold">{section.name}</h3>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default PrivateRoom;
