
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);
  const [authToken, setAuthToken] = useState(localStorage.getItem('authToken'));
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      if (pb.authStore.isValid) {
        setCurrentUser(pb.authStore.model);
        await fetchSubscription();
      }
      setInitialLoading(false);
    };
    checkAuth();
  }, []);

  const fetchSubscription = async () => {
    try {
      const token = localStorage.getItem('authToken');
      if (!token) return;

      const response = await apiServerClient.fetch('/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch subscription');
      }

      const data = await response.json();
      setSubscription(data.subscription);
    } catch (error) {
      console.error('Subscription fetch error:', error);
    }
  };

  const loginWithGoogle = () => {
    pb.collection('users').authWithOAuth2({ provider: 'google' })
      .then(async (authData) => {
        setCurrentUser(authData.record);
        
        const token = pb.authStore.token;
        localStorage.setItem('authToken', token);
        setAuthToken(token);
        
        await fetchSubscription();
        navigate('/private-room');
      })
      .catch((err) => {
        console.error('Google login failed:', err);
      });
  };

  const logout = () => {
    pb.authStore.clear();
    localStorage.removeItem('authToken');
    setCurrentUser(null);
    setSubscription(null);
    setAuthToken(null);
    navigate('/');
  };

  const hasActiveSubscription = () => {
    if (!subscription) return false;
    if (subscription.status !== 'active') return false;
    
    const expiresAt = new Date(subscription.expires_at);
    return expiresAt > new Date();
  };

  const value = {
    currentUser,
    subscription,
    authToken,
    initialLoading,
    loginWithGoogle,
    logout,
    hasActiveSubscription,
    refreshSubscription: fetchSubscription
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
