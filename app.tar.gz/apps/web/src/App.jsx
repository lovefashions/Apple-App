import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext.jsx';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from './components/ScrollToTop.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import HomePage from './pages/HomePage.jsx';
import BioPage from './pages/BioPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import StorePage from './pages/StorePage.jsx';
import MorePage from './pages/MorePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import PrivateRoom from './pages/PrivateRoom.jsx';
import NewsPage from './pages/NewsPage.jsx';
import PortfolioPage from './pages/PortfolioPage.jsx';
import GalleryPage from './pages/GalleryPage.jsx';
import ExtrasPage from './pages/ExtrasPage.jsx';
import BlogPage from './pages/BlogPage.jsx';
import PrivateStorePage from './pages/PrivateStorePage.jsx';
import SuccessPage from './pages/SuccessPage.jsx';
import CancelPage from './pages/CancelPage.jsx';

function App() {
  return (
    <Router>
      <AuthProvider>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/bio" element={<BioPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/store" element={<StorePage />} />
          <Route path="/more" element={<MorePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/success" element={<SuccessPage />} />
          <Route path="/cancel" element={<CancelPage />} />
          <Route
            path="/private-room"
            element={
              <ProtectedRoute>
                <PrivateRoom />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/news"
            element={
              <ProtectedRoute>
                <NewsPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/portfolio"
            element={
              <ProtectedRoute>
                <PortfolioPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/gallery"
            element={
              <ProtectedRoute>
                <GalleryPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/extras"
            element={
              <ProtectedRoute>
                <ExtrasPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/blog"
            element={
              <ProtectedRoute>
                <BlogPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/private-room/store"
            element={
              <ProtectedRoute>
                <PrivateStorePage />
              </ProtectedRoute>
            }
          />
        </Routes>
        <Toaster />
      </AuthProvider>
    </Router>
  );
}

export default App;