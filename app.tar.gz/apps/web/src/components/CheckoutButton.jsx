
import React, { useState } from 'react';
import apiServerClient from '@/lib/apiServerClient';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext.jsx';

const CheckoutButton = ({ amount, productName }) => {
  const [loading, setLoading] = useState(false);
  const { currentUser } = useAuth();

  const handleCheckout = async () => {
    setLoading(true);
    try {
      const response = await apiServerClient.fetch('/paypal/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          productName,
          userId: currentUser?.id
        })
      });

      if (!response.ok) throw new Error('Checkout failed');

      const data = await response.json();
      window.open(data.approvalUrl, '_blank');
    } catch (error) {
      console.error('Checkout error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={handleCheckout}
      disabled={loading}
      className="bg-gold-500 text-black hover:bg-gold-400 font-semibold px-8 py-6 text-lg"
    >
      {loading ? 'Processing...' : `Unlock Access - $${amount}`}
    </Button>
  );
};

export default CheckoutButton;
