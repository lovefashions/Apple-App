import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Youtube } from 'lucide-react';
const Footer = () => {
  return <footer className="bg-black border-t border-gold-500/20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="text-xl font-bold mb-4">
              <span className="text-gold-500">Apple Jucy</span>
              <span className="ml-2">Entertainment</span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed">
              Exclusive premium content and experiences for discerning members.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-gold-500">Quick Links</h3>
            <nav className="space-y-2">
              <Link to="/" className="block text-sm text-white/60 hover:text-gold-500 transition-colors">
                Home
              </Link>
              <Link to="/bio" className="block text-sm text-white/60 hover:text-gold-500 transition-colors">
                Bio
              </Link>
              <Link to="/contact" className="block text-sm text-white/60 hover:text-gold-500 transition-colors">
                Contact
              </Link>
              <Link to="/store" className="block text-sm text-white/60 hover:text-gold-500 transition-colors">
                Store
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-gold-500">Connect</h3>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-gold-500 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-gold-500 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-gold-500 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gold-500/20 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-white/60">
            © 2026 Apple Juicy Entertainment. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link to="/privacy" className="text-sm text-white/60 hover:text-gold-500 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-sm text-white/60 hover:text-gold-500 transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;