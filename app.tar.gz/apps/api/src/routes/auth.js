import express from 'express';
import axios from 'axios';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// POST /auth/google - Exchange Google OAuth code for tokens and create/update user
router.post('/google', async (req, res) => {
  const { code, redirectUri } = req.body;

  if (!code || !redirectUri) {
    return res.status(400).json({ error: 'code and redirectUri are required' });
  }

  // Exchange authorization code for tokens
  const tokenResponse = await axios.post('https://oauth2.googleapis.com/token', {
    code,
    client_id: process.env.GOOGLE_CLIENT_ID,
    client_secret: process.env.GOOGLE_CLIENT_SECRET,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code',
  });

  if (!tokenResponse.data.access_token) {
    throw new Error('Failed to obtain Google access token');
  }

  // Get user info from Google
  const userInfoResponse = await axios.get('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: {
      Authorization: `Bearer ${tokenResponse.data.access_token}`,
    },
  });

  const googleUser = userInfoResponse.data;
  const { id: googleId, email, name, picture } = googleUser;

  if (!googleId || !email) {
    throw new Error('Invalid Google user data');
  }

  // Check if user exists in PocketBase
  let user;
  try {
    const existingUsers = await pb.collection('users').getFullList({
      filter: `google_id = "${googleId}"`,
    });

    if (existingUsers.length > 0) {
      // Update existing user
      user = await pb.collection('users').update(existingUsers[0].id, {
        google_id: googleId,
        email,
        name,
        profile_image: picture || '',
      });
    } else {
      // Create new user
      user = await pb.collection('users').create({
        google_id: googleId,
        email,
        name,
        profile_image: picture || '',
      });
    }
  } catch (error) {
    logger.error('PocketBase user operation failed:', error.message);
    throw new Error('Failed to create or update user');
  }

  // Generate auth token for the user
  const authData = await pb.collection('users').authWithPassword(email, googleId);

  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      profile_image: user.profile_image,
      google_id: user.google_id,
    },
    token: authData.token,
  });
});

export default router;
