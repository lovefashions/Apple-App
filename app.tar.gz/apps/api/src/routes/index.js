import { Router } from 'express';
import healthCheck from './health-check.js';
import authRouter from './auth.js';
import meRouter from './me.js';
import paypalRouter from './paypal.js';
import accessRouter from './access.js';
import contentRouter from './content.js';
import messagesRouter from './messages.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/auth', authRouter);
    router.use('/me', meRouter);
    router.use('/paypal', paypalRouter);
    router.use('/access', accessRouter);
    router.use('/content', contentRouter);
    router.use('/messages', messagesRouter);

    return router;
};
