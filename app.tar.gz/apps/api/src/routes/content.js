import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

const VALID_TYPES = ['news', 'portfolio', 'gallery', 'extras', 'blog', 'store'];

// Helper function to extract and verify auth token
function getAuthToken(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('Missing or invalid authorization header');
  }
  return authHeader.substring(7);
}

// GET /content/private-room - Get private content for authenticated users with active subscription
router.get('/private-room', async (req, res) => {
  const { type } = req.query;

  if (!type || !VALID_TYPES.includes(type)) {
    return res.status(400).json({ error: `type must be one of: ${VALID_TYPES.join(', ')}` });
  }

  const token = getAuthToken(req);

  // Verify token and get user
  let user;
  try {
    pb.authStore.save(token);
    const authRecord = pb.authStore.record;
    if (!authRecord) {
      throw new Error('Invalid token');
    }
    user = await pb.collection('users').getOne(authRecord.id);
  } catch (error) {
    logger.error('Token verification failed:', error.message);
    throw new Error('Unauthorized');
  }

  // Check subscription status
  let hasActiveSubscription = false;
  try {
    const subscriptions = await pb.collection('subscriptions').getFullList({
      filter: `user_id = "${user.id}"`,
    });

    if (subscriptions.length > 0) {
      const subscription = subscriptions[0];
      const expiresAt = new Date(subscription.expires_at);
      hasActiveSubscription = expiresAt > new Date();
    }
  } catch (error) {
    logger.warn('Failed to fetch subscription:', error.message);
  }

  if (!hasActiveSubscription) {
    return res.status(403).json({
      error: 'Subscription expired',
      message: 'Your subscription has expired. Please renew to access this content.',
      renewalUrl: '/renew',
    });
  }

  // Fetch content filtered by type
  let content = [];
  try {
    content = await pb.collection('content').getFullList({
      filter: `type = "${type}"`,
      sort: '-created',
    });
  } catch (error) {
    logger.warn('Failed to fetch content:', error.message);
  }

  res.json(content);
});

export default router;
