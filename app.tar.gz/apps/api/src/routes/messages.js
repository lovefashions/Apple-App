import express from 'express';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();

// POST /messages - Create a contact message
router.post('/', async (req, res) => {
  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email, and message are required' });
  }

  const record = await pb.collection('messages').create({
    name,
    email,
    message,
  });

  res.json({
    success: true,
    id: record.id,
  });
});

export default router;
