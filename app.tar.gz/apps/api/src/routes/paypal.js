import express from 'express';
import axios from 'axios';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

const PAYPAL_API_BASE = process.env.PAYPAL_MODE === 'production'
  ? 'https://api.paypal.com'
  : 'https://api.sandbox.paypal.com';

// Helper function to get PayPal access token
async function getPayPalAccessToken() {
  const auth = Buffer.from(
    `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
  ).toString('base64');

  const response = await axios.post(`${PAYPAL_API_BASE}/v1/oauth2/token`, 'grant_type=client_credentials', {
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });

  if (!response.data.access_token) {
    throw new Error('Failed to obtain PayPal access token');
  }

  return response.data.access_token;
}

// POST /paypal/create-order - Create PayPal order
router.post('/create-order', async (req, res) => {
  const { amount, productName, userId } = req.body;

  if (!amount || !productName || !userId) {
    return res.status(400).json({ error: 'amount, productName, and userId are required' });
  }

  const accessToken = await getPayPalAccessToken();

  const orderResponse = await axios.post(
    `${PAYPAL_API_BASE}/v2/checkout/orders`,
    {
      intent: 'CAPTURE',
      purchase_units: [
        {
          amount: {
            currency_code: 'USD',
            value: amount.toString(),
          },
          description: productName,
          custom_id: userId,
        },
      ],
      application_context: {
        return_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/paypal/success`,
        cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/paypal/cancel`,
      },
    },
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    }
  );

  if (!orderResponse.data.id) {
    throw new Error('Failed to create PayPal order');
  }

  const approvalUrl = orderResponse.data.links.find(link => link.rel === 'approve')?.href;

  res.json({
    id: orderResponse.data.id,
    approvalUrl,
  });
});

// POST /paypal/webhook - Handle PayPal webhook
router.post('/webhook', async (req, res) => {
  const event = req.body;

  logger.info('PayPal webhook received:', event.event_type);

  if (event.event_type !== 'PAYMENT.CAPTURE.COMPLETED') {
    return res.status(200).json({ received: true });
  }

  const capture = event.resource;
  const userId = capture.supplementary_data?.related_ids?.order_reference_id || capture.custom_id;
  const orderId = capture.id;

  if (!userId || !orderId) {
    logger.warn('Missing userId or orderId in webhook');
    return res.status(200).json({ received: true });
  }

  try {
    // Calculate subscription dates
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000); // 60 days from now

    // Check if subscription exists
    const existingSubscriptions = await pb.collection('subscriptions').getFullList({
      filter: `user_id = "${userId}"`,
    });

    if (existingSubscriptions.length > 0) {
      // Update existing subscription
      await pb.collection('subscriptions').update(existingSubscriptions[0].id, {
        status: 'active',
        starts_at: now.toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_id: orderId,
      });
    } else {
      // Create new subscription
      await pb.collection('subscriptions').create({
        user_id: userId,
        status: 'active',
        starts_at: now.toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_id: orderId,
      });
    }

    logger.info(`Subscription updated for user ${userId}`);
  } catch (error) {
    logger.error('Failed to update subscription:', error.message);
  }

  res.status(200).json({ received: true });
});

export default router;
