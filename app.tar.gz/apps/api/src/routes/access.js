import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper function to extract and verify auth token
function getAuthToken(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('Missing or invalid authorization header');
  }
  return authHeader.substring(7);
}

// GET /access/check - Check if user has active subscription
router.get('/check', async (req, res) => {
  const token = getAuthToken(req);

  // Verify token and get user
  let user;
  try {
    pb.authStore.save(token);
    const authRecord = pb.authStore.record;
    if (!authRecord) {
      throw new Error('Invalid token');
    }
    user = await pb.collection('users').getOne(authRecord.id);
  } catch (error) {
    logger.error('Token verification failed:', error.message);
    throw new Error('Unauthorized');
  }

  // Fetch subscription
  let hasAccess = false;
  let expiresAt = null;
  let daysRemaining = 0;

  try {
    const subscriptions = await pb.collection('subscriptions').getFullList({
      filter: `user_id = "${user.id}"`,
    });

    if (subscriptions.length > 0) {
      const subscription = subscriptions[0];
      expiresAt = new Date(subscription.expires_at);
      const now = new Date();
      hasAccess = expiresAt > now;
      daysRemaining = Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24));
    }
  } catch (error) {
    logger.warn('Failed to fetch subscription:', error.message);
  }

  if (!hasAccess) {
    return res.json({
      hasAccess: false,
      expiresAt,
      daysRemaining: Math.max(0, daysRemaining),
      renewalUrl: '/renew',
    });
  }

  res.json({
    hasAccess: true,
    expiresAt,
    daysRemaining,
  });
});

export default router;
