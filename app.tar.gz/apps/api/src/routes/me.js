import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper function to extract and verify auth token
function getAuthToken(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('Missing or invalid authorization header');
  }
  return authHeader.substring(7);
}

// GET /me - Get current user profile and subscription status
router.get('/', async (req, res) => {
  const token = getAuthToken(req);

  // Verify token and get user
  let user;
  try {
    // Set the token in the auth store
    pb.authStore.save(token);
    
    // Get current user from token
    const authRecord = pb.authStore.record;
    if (!authRecord) {
      throw new Error('Invalid token');
    }

    user = await pb.collection('users').getOne(authRecord.id);
  } catch (error) {
    logger.error('Token verification failed:', error.message);
    throw new Error('Unauthorized');
  }

  // Fetch subscription data
  let subscription = null;
  let isActive = false;

  try {
    const subscriptions = await pb.collection('subscriptions').getFullList({
      filter: `user_id = "${user.id}"`,
    });

    if (subscriptions.length > 0) {
      subscription = subscriptions[0];
      const expiresAt = new Date(subscription.expires_at);
      isActive = expiresAt > new Date();
    }
  } catch (error) {
    logger.warn('Failed to fetch subscription:', error.message);
  }

  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      profile_image: user.profile_image,
    },
    subscription: subscription ? {
      id: subscription.id,
      status: subscription.status,
      starts_at: subscription.starts_at,
      expires_at: subscription.expires_at,
      payment_id: subscription.payment_id,
    } : null,
    isActive,
  });
});

export default router;
